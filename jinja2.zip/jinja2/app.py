from flask import Flask, render_template


app = Flask(__name__)

@app.route('/')
def home():
    
    nome = 'Ana'
    idade = '18'

    return render_template('index.html', nome = nome, idade = idade) 


@app.route('/dados_usuario')
def dados():
    
    dados_usuario = {"nome": "Ana", "email": "ana@email.com"}

    return render_template('dados.html', dados_usuario = dados_usuario) 

@app.route('/lista')
def lista():

    lista_alunos = {
        "nome": "ana", "nota": "8",
        "nome": "pedro", "nota": "4"
        }
    
    return render_template('alunos.html', lista_alunos = lista_alunos)

if __name__ == '__main__':
    app.run(debug=True)